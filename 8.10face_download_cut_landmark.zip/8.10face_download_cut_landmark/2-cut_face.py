# -*- coding:utf-8 -*-
import face_recognition as fr
import os,json,cv2,time
import numpy as np
import glob
import change_size

filepath=glob.glob("/home/dooncloud/桌面/practice/8.10face_download_cut_landmark/image/*")
# filepath=glob.glob("/home/dooncloud/桌面/practice/8.10face_download_cut_landmark/image/*")
# print(filepath)
k = 0
yaq = 0
ldq = 0
for yaq,i in enumerate(filepath):
    if yaq < 0:continue
    print(str(yaq+1) + "/" + str(len(filepath)))
    # print(i)
    try:
        image = cv2.imread(i)
        stu_img = image
    except IOError:
        os.remove(i)
        print('del the bad pic' + i)
        continue

    try:
        zzz = image.shape
    except AttributeError:
        continue
    if image.shape[0] > 1500 or image.shape[1] > 1500:
        if image.shape[0] > image.shape[1]:
            size = (1500,int(1500*(image.shape[0]/(image.shape[0]*1.))))
        else:
            size = (int(1500*(image.shape[0]/(image.shape[0]*1.))),1500)
        image = cv2.resize(image, size)
        stu_img = cv2.resize(stu_img, size)
        zzz = stu_img.shape
    try:
        stu_loc = fr.face_locations(stu_img, model="cnn")  # 脸部128向量
    except RuntimeError:
        print ('error,rerun from ' + str(ldq + 1))
        break
        # f_1 = open('where.txt','r+')
        # f_1.write(str(i))
        # f_1.close()
        continue
    ldq = yaq
    print(stu_loc) # 脸部位置 四个角

    
    if len(stu_loc) >= 1:   # 图片中至少有一个人
        for l in stu_loc:
            # cv2.rectangle(image, (l[3],l[0]), (l[1],l[2]), (0,255,0), 2)
            h = (l[2] - l[0])
            w = (l[1] - l[3])
            # print(l[0],l[2],l[3],l[1])
            # # cropped = image[l[0]-h/2:l[2]+2*h,l[3]-w:l[1]+w]
            # cropped = image[l[0] :l[2],l[3]:l[1]]
            # # if cropped.shape[0] > 5 * cropped.shape[1] or cropped.shape[1] > 5 * cropped.shape[0]:continue
            a = l[0] - int(h/4)
            b= l[2]+ int(h/3)
            c = l[3]-int(w/8)
            d = (l[1]+int(w/8))
            if (a < 0):
                a = 0
            if (b >= np.shape(stu_img)[0]):
                b = np.shape(stu_img)[0]  - 1
            if (c < 0):
                c = 0 
            if d >= np.shape(stu_img)[1]:
                d = np.shape(stu_img)[1] - 1
            # else:
            # cropped = stu_img[l[0] - int(h/4):l[2]+ int(h/2),l[3]-int(w/8):l[1]+int(w/8)]
            cropped = stu_img[a:b,c:d]
            cropped = change_size.process_image(cropped)
            cv2.imwrite("/home/dooncloud/桌面/practice/8.10face_download_cut_landmark/cut_face_better/"+str(k)+'.jpg', cropped)
            k = k + 1
            print('==>' + str(k+1))


    # else:
    #     cv2.imwrite("/home/ubuntu/MyTestFile/Pic_Downloader/img/tang1_"+str(k)+'.jpg', stu_img)
    #     k = k + 1
    # print('==>' + str(k+1))

        # cv2.imwrite("/home/ubuntu/MyTestFile/Pic_Downloader/img/"+str(k)+'.jpg', image)
    # else:
    #     # cv2.imwrite("/home/ubuntu/MyTestFile/Pic_Downloader/img/"+str(k)+'.jpg', image)
    #     continue
    # k = k + 1
    # cv2.imshow("1", stu_img)
    # cv2.waitKey(0)
# f_1 = open('where.txt','r+')
# f_1.write(str(0))
# f_1.close()
